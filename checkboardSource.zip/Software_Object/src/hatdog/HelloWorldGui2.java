package hatdog;

import java.awt.Color;
import java.awt.Graphics;
import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.Font;
 
	
	

	public class HelloWorldGui2 extends JPanel {


		
    //draw squares
	    public void paint(Graphics g) {

	    	
	    	String[][] operators = {
	    							{"x","","÷","","−","","+",""},
	    							{"","÷","","x","","+","","−"},
	    							{"−","","+","","x","","÷",""},
	    							{"","+","","−","","÷","","x"},
	    							{"x","","÷","","−","","+",""},
	    							{"","÷","","x","","+","","−"},
	    							{"−","","+","","x","","÷",""},
	    							{"","+","","−","","÷","","x"}
	    							
	    							};
	    	
	    	String[][] valueOfEachPiece = {
	    									{"2","9","5","6","8","1","11","4"},
	    									{"0","7","3","10","10","3","7","0"},
	    									{"4","11","1","8","6","5","9","2"}
	    									};
	    	
	    	
	    	Font font = new Font("Arial", Font.BOLD, 30);
	    	Font fontForNumbers = new Font("Arial", Font.BOLD, 20);
	    	
	        int x = 0;
	        int y = 0;
	        int size = 50;
	        int boardSize = 8;
	        int territories = 3;
	        int pieceSize = size -10;
	        boolean isBlack = true;

	        //draw squares
	        
	        for (int i = 0; i < boardSize; i++) {
	            for (int j = 0; j < boardSize; j++) {
	                if (isBlack) {
	                    g.setColor(Color.WHITE);
	                    isBlack = false;
	                } else {
	                    g.setColor(Color.BLACK);
	                    isBlack = true;
	                }
	                g.fillRect(x + 50, y + 50, size, size);
	                x += size;
	            }
	            x = 0;
	            y += size;
	            isBlack = !isBlack;

              
	        }
	        //draw String operators
	        g.setFont(font);
	        for (int row = 0; row < boardSize; row++) {
	            for (int col = 0; col < boardSize; col++) {
	            	int x1 = col * size;
	                int y1 = row * size;
	                
	                
	                if ((row + col) % 2 == 0) {
	                    	g.setColor(Color.BLACK);
		                    g.drawString(operators[row][col], x1 + pieceSize / 2 - 5 + 50, y1 + pieceSize / 2 + 15 + 50);
	                    	
	                }
	            }
	        }
	        //territory of player1
	        for(int row = 0; row < territories; row++) {
	        	for(int col = 0; col < boardSize; col++) {
	        		int x1 = (col * size + size / 2 - pieceSize / 2) + 50;
	        		int y1 = (row * size + size / 2 - pieceSize / 2) + 50;
	        		if((row + col) % 2 == 0) {
	        			g.setColor(Color.BLACK);
	        			g.fillOval(x1, y1, pieceSize, pieceSize);
	        			
	        		}
	        	}
	        }
	        g.setFont(fontForNumbers);
	        for(int row = 0; row < territories; row++) {
	        	for(int col = 0; col < boardSize; col++) {
	        		int x1 = (col * size + size / 2 - pieceSize / 2) + 60;
	        		int y1 = (row * size + size / 2 - pieceSize / 2) + 80;
	        		if((row + col) % 2 == 0) {
	        			g.setColor(Color.white);
	        			g.drawString(valueOfEachPiece[row][col], x1, y1);
	        		}
	        	}
	        }
	      //territory of player2
	        for(int row = 0; row < territories; row++) {
	        	for(int col = 0; col < boardSize; col++) {
	        		int x1 = ((col * size + size / 2 - pieceSize / 2) + 50);
	        		int y1 = ((row + 5) * size + size / 2 - pieceSize / 2) + 50;
	        		if((row + col) % 2 == 1) {
	        			g.setColor(Color.white);
	        			g.fillOval(x1, y1, pieceSize, pieceSize);
	        			g.setColor(Color.BLACK);
	        			g.drawOval(x1, y1, pieceSize, pieceSize);
	        			
	        		}
	        	}
	        }
	        g.setFont(fontForNumbers);
	        for(int row = 0; row < territories; row++) {
	        	for(int col = 0; col < boardSize; col++) {
	        		int x1 = ((col * size + size / 2 - pieceSize / 2) + 60);
	        		int y1 = (((row + 5) * size + size / 2 - pieceSize / 2) + 80);
	        		if((row + col) % 2 == 1) {
	        			g.setColor(Color.black);
	        			g.drawString(valueOfEachPiece[row][col], x1, y1);
	        		}
	        	}
	        }
	    }
      

	    public static void main(String[] args) {
	        JFrame frame = new JFrame("Checker Board");
	        HelloWorldGui2 checkerBoard = new HelloWorldGui2();
	        checkerBoard.setBounds(100, 100, 400, 400);
	        frame.add(checkerBoard);
	        frame.setSize(515, 535);
	        frame.setVisible(true);
	        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	    }
	}
